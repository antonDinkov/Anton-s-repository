window.addEventListener("load", solve);

function solve() {
  //TODO...

  const snowmanName = document.querySelector('#snowman-name');
  const height = document.querySelector('#snowman-height');
  const locations = document.querySelector('#location');
  const creatorName = document.querySelector('#creator-name');
  const specialAttr = document.querySelector('#special-attribute');
  const addBtn = document.querySelector('.add-btn');

  const inputArr = [snowmanName, height, locations, creatorName, specialAttr];


  addBtn.addEventListener('click', (e) => {
    e.preventDefault();

    for (const element of inputArr) {
      if (element.value === '') {
        return;
      }
    }

    addBtn.disabled = true;

    const snowmanPreview = document.querySelector('.snowman-preview');

    const li = document.createElement('li');
    li.className = 'snowman-info';

    const articlePrev = document.createElement('article');

    const inputObj = {
      Name: snowmanName.value,
      Height: height.value,
      Location: locations.value,
      Creator: creatorName.value,
      Attribute: specialAttr.value
    };

    for (const key in inputObj) {
      const p = document.createElement('p');
      p.textContent = `${key}: ${inputObj[key]}`;
      articlePrev.appendChild(p);
    }

    li.appendChild(articlePrev);
    snowmanPreview.appendChild(li);

    const div = document.createElement('div');
    div.className = 'btn-container';

    const editBtn = document.createElement('button');
    editBtn.className = 'edit-btn';
    editBtn.textContent = 'Edit';

    const nextBtn = document.createElement('button');
    nextBtn.className = 'next-btn';
    nextBtn.textContent = 'Next';

    div.appendChild(editBtn);
    div.appendChild(nextBtn);

    li.appendChild(div);

    for (const element of inputArr) {
      element.value = '';
    }


    editBtn.addEventListener('click', (e) => {
      addBtn.disabled = false;

      let i = 0;
      for (const key in inputObj) {
        inputArr[i].value = inputObj[key];
        i++;
      }

      e.target.parentElement.parentElement.remove();
    });


    nextBtn.addEventListener('click', (e) => {

      e.target.parentElement.parentElement.remove();
     
      let articleElementContinue = document.createElement("article");
      articleElementContinue = articlePrev;

      const sendBtn = document.createElement('button');
      sendBtn.className = 'send-btn';
      sendBtn.textContent = 'Send';

      articleElementContinue.appendChild(sendBtn);

      const snowList = document.querySelector('.snow-list');

      const secondLi = document.createElement('li');
      secondLi.className = 'snowman-content';

      secondLi.appendChild(articleElementContinue);

      snowList.appendChild(secondLi);


      sendBtn.addEventListener('click', (e) => {
        const main = document.querySelector('#hero');
        main.remove();

        const img = document.querySelector('#back-img');
        img.hidden = false;

        const backBtn = document.createElement('button');
        backBtn.className = 'back-btn';
        backBtn.textContent = 'Back';

        const body = document.querySelector('.body');

        body.appendChild(backBtn);

        backBtn.addEventListener('click', (e) => {
          location.reload();
        })
      })
    })
  })
}
